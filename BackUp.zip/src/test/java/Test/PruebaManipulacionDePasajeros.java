package Test;

import Modelo.Persistencia.DaoPasajeroMYSQL;

public class PruebaManipulacionDePasajeros {

    public static void main(String[] args) {
        //////////////////////////////////////////////////
        DaoPasajeroMYSQL daoPasajeroMYSQL = new DaoPasajeroMYSQL();
        ////////////////////////////////////////////////////////////

        System.out.println("Conexion a BBDD = " + daoPasajeroMYSQL.abrirConexion());
        ////////////////////////////////////////////////////////////////////////////

        System.out.println("Pasajero añadido a un coche = " + daoPasajeroMYSQL.addPasajeroA_Coche(5, 3));
        //System.out.println("Pasajero sacado de un coche = " + daoPasajeroMYSQL.sacarPasajeroDeunCoche(5, 1));

        /////////////////////////////////////////////////////////////////////////////
        System.out.println("BBDD cerrada = " + daoPasajeroMYSQL.cerrarConexion());

    }

}
