package Modelo.Persistencia.Interfaz;

/*CREATE TABLE PASAJEROS(
ID INT(11) NOT NULL UNIQUE AUTO_INCREMENT,
COCHEID INT(11) NOT NULL,
NOMBRE VARCHAR(45),
EDAD INT(11),
PESO FLOAT(11),
PRIMARY KEY (id),
FOREIGN KEY (COCHEID) REFERENCES COCHES(ID));*/
import Modelo.Entidad.Pasajero;
import java.util.List;

/**
 *
 * @author Gonzalo Solís Campos
 */
public interface DaoPasajero {

    /**
     *
     * @param pasajero
     * @return
     */
    public boolean addPasajero(Pasajero pasajero);

    /**
     *
     * @param id
     * @return
     */
    public boolean borrarPasajero(int id);

    /**
     *
     * @param id
     * @return
     */
    public Pasajero obtenerPasajero(int id);

    /**
     *
     * @return
     */
    public List<Pasajero> listarPasajero();

    /**
     *
     * @param idPasajero
     * @param idCoche
     * @return
     */
    public boolean sacarPasajeroDeunCoche(int idPasajero, int idCoche);

    /**
     *
     * @param idPasajero
     * @param idCoche
     * @return
     */
    public boolean addPasajeroA_Coche(int idPasajero, int idCoche);

    /**
     *
     * @param idCoche
     * @return
     */
    public List<Pasajero> listaDePasajerosQueHayEnUnCoche(int idCoche);

}
